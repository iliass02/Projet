<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8" />
    <title>Inscription</title>
    <link rel="shortcut icon" type="image/x-icon" href="css/images/zzz.ico" />
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
</head>
<body>
         
<FORM action="donnee.php" method="post">
<table>
   <tr>
       <td><LABEL for="login">Login</LABEL></td>
       <td><INPUT type="text" id="login" name="email[0][login]" required><BR></td>
   </tr>
   <tr>
       <td><LABEL for="nom">Nom / Prenom :</LABEL></td>
       <td><INPUT type="text" id="nom" name="email[0][nom]" required><BR></td>
   </tr>
   <tr>
       <td><LABEL for="email">Mail : </LABEL></td>
       <td><INPUT type="text" id="email" name="email[0][email]" required></td>
   </tr>
   <tr>
       <td><LABEL for="mdp_a">Mot de passe</LABEL></td>
       <td><INPUT type="password" id="pwd" name="email[0][pwd]" required><BR></td>
   </tr>
   <tr>
       <td><LABEL for="telephone">Telephone</LABEL></td>
       <td><INPUT type="number" id="telephone" name="email[0][telephone]" required><BR></td>
   </tr>
   <tr>
   <td><INPUT type="submit" value="inscription"></td>
    <td><INPUT type="reset"></td>
   </tr>
</table>
 </FORM>
   </body>
</html>