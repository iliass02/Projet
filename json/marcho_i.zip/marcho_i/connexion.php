<html>
<head>
	<title>Connexion</title>
</head>
<body>	
	<form method="get" action="test.php">
		<label>login ou adresse mail</label>
		<input type="text" name="email"></br>
		<label>Mots de passe</label>
		<input type="password" name="pwd"></br>
		<button name="Connexion">Connexion</button>
	</form>
</body>
</html>